create function select_person_eo(integer) returns TABLE(f1 text, f2 text, f3 text, f4 text, f5 text)
LANGUAGE SQL
AS $$
SELECT person.name, person.surname, person.patronymic, position.name, subdivision.name FROM educ_odject
LEFT JOIN person_eo ON educ_odject.id = person_eo.id_eo
LEFT JOIN person ON person_eo.id_person = person.id
LEFT JOIN position ON person_eo.id_pos = position.id
LEFT JOIN subdivision ON person_eo.id_pos = subdivision.id
WHERE person_eo.id_eo = $1;
$$;
