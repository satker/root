create function insert_child_classifier(integer, integer) returns void
LANGUAGE SQL
AS $$
UPDATE classifier
    SET id_parent = $1 FROM valid_class
        WHERE classifier.id = $2
              AND valid_class.id_classifier = $1
              AND valid_class.id_valid_class = $2;
$$;
