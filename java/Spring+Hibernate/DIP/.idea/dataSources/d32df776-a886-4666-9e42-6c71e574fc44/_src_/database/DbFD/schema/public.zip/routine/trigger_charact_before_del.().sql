create function trigger_charact_before_del() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
 IF (SELECT count(*) FROM charact_value where id_charact = old.id)>0
  THEN DELETE FROM charact_value WHERE id_charact = OLD.id;
  END IF;
 IF (SELECT count(*) FROM charact_class where id_charact = old.id)>0
  THEN DELETE FROM charact_class WHERE id_charact = OLD.id;
  END IF;
return OLD;
END;
$$;
