create function trigger_educ_obj_before_del() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
 IF (SELECT count(*) FROM person_eo where id_eo = old.id)>0
  THEN DELETE FROM person_eo WHERE id_eo = OLD.id;
  END IF;
 IF (SELECT count(*) FROM position_eo where id_eo = old.id)>0
  THEN DELETE FROM position_eo WHERE id_eo = OLD.id;
  END IF;
 IF (SELECT count(*) FROM charact_value where id_eo = old.id)>0
  THEN DELETE FROM charact_value WHERE id_eo = old.id;
  END IF;
return OLD;
END;
$$;
