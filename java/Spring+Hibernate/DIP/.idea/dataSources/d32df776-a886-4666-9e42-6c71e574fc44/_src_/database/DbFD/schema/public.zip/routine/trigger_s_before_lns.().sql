create function trigger_s_before_lns() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
NEW.enabled = TRUE ;
NEW.rolename = 'ROLE_USER' ;
return NEW;
END;
$$;
