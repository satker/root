create function select_class_chart(integer) returns TABLE(f1 text)
LANGUAGE SQL
AS $$
SELECT charact.name FROM charact
LEFT JOIN charact_class ON charact_class.id_charact = charact.id
LEFT JOIN classifier ON classifier.id = charact_class.id_classifier
WHERE classifier.id = $1;
$$;
