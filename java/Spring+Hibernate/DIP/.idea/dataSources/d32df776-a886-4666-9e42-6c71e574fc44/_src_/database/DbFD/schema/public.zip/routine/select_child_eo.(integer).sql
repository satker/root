create function select_child_eo(integer) returns TABLE(f2 text)
LANGUAGE SQL
AS $$
SELECT eo.name
FROM educ_odject as eo
  JOIN position_eo as pos ON eo.id = pos.id_eo OR eo.id = pos.id_in_eo
WHERE pos.id_eo = $1 and eo.id = pos.id_in_eo;
$$;
