create function trigger_classifier_before_del() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
 IF (SELECT count(*) FROM valid_class where id_classifier = old.id OR id_valid_class = old.id)>0
  THEN DELETE FROM valid_class as vc WHERE vc.id_classifier=OLD.id OR vc.id_valid_class = OLD.id;
  END IF;
 IF (SELECT count(*) FROM educ_odject where id_classifier = old.id)>0
  THEN UPDATE educ_odject as eo SET id_classifier = NULL
    WHERE eo.id_classifier = old.id;
  END IF;
 IF (SELECT count(*) FROM charact_class where id_classifier = old.id)>0
  THEN DELETE FROM charact_class WHERE id_classifier = old.id;
  END IF;
return OLD;
END;
$$;
