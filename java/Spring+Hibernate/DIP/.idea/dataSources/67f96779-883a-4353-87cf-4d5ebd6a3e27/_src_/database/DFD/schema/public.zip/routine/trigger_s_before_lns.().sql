create function trigger_s_before_lns() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN 
NEW.enabled = '1' ; 
NEW.rolename = 'ROLE_USER' ; 
return NEW; 
END;
$$;
